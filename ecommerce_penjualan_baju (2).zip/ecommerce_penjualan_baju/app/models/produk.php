<?php

require_once __DIR__ . '/../config/Database.php';

class Produk {

    private $db;

    public function __construct() {
        $this->db = Database::connect();
    }

    // AMBIL SEMUA PRODUK
    public function all() {
        $query = $this->db->query("SELECT * FROM produk");
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    // SIMPAN PRODUK (WAJIB UNTUK UPLOAD)
    public function insert($nama, $harga, $gambar) {

        $query = "INSERT INTO produk (nama, harga, gambar)
                  VALUES (:nama, :harga, :gambar)";

        $stmt = $this->db->prepare($query);

        return $stmt->execute([
            'nama' => $nama,
            'harga' => $harga,
            'gambar' => $gambar
        ]);
    }

    // HAPUS PRODUK
    public function delete($id) {
        $query = "DELETE FROM produk WHERE id = :id";
        $stmt = $this->db->prepare($query);

        return $stmt->execute([
            'id' => $id
        ]);
    }
}