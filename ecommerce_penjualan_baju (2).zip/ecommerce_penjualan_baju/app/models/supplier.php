<?php
require_once __DIR__ . '/../config/Database.php';

class Supplier {

    private $db;

    public function __construct() {
        $this->db = Database::connect();
    }

    public function all() {
        return $this->db->query("SELECT * FROM supplier")->fetchAll(PDO::FETCH_ASSOC);
    }
}