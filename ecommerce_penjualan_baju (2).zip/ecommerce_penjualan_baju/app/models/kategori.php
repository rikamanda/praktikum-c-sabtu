<?php
require_once __DIR__ . '/../config/Database.php';

class Kategori {

    private $db;

    public function __construct() {
        $this->db = Database::connect();
    }

    public function all() {
        return $this->db->query("SELECT * FROM kategori")->fetchAll(PDO::FETCH_ASSOC);
    }
}