<?php

class Database {
    private static $host = "localhost";
    private static $db   = "butik_db"; // pastikan ini sama di phpMyAdmin
    private static $user = "root";
    private static $pass = "";
    private static $conn = null;

    public static function connect() {
        if (self::$conn == null) {
            try {
                self::$conn = new PDO(
                    "mysql:host=".self::$host.";dbname=".self::$db,
                    self::$user,
                    self::$pass
                );
                self::$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            } catch (Exception $e) {
                die("Koneksi gagal: " . $e->getMessage());
            }
        }
        return self::$conn;
    }
}