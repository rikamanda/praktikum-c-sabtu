<?php

require_once __DIR__ . '/../models/Transaksi.php';

class TransaksiController {

    public function index() {
        $model = new Transaksi();
        $data = $model->all();
        require __DIR__ . '/../views/transaksi/index.php';
    }
}