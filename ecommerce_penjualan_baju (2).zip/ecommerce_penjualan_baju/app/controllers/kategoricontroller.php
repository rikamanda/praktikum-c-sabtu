<?php

require_once __DIR__ . '/../models/Kategori.php';

class KategoriController {

    public function index() {
        $model = new Kategori();
        $data = $model->all();
        require __DIR__ . '/../views/kategori/index.php';
    }
}