<?php
require_once __DIR__ . '/../models/Produk.php';

class ProdukController {

    // TAMPIL PRODUK
    public function index() {
        $model = new Produk();
        $data = $model->all();
        require __DIR__ . '/../views/produk/index.php';
    }

    // HALAMAN TAMBAH PRODUK
    public function tambah() {
        require __DIR__ . '/../views/produk/tambah.php';
    }

    // SIMPAN + UPLOAD GAMBAR
    public function simpan() {

        // cek file masuk
        if(!isset($_FILES['gambar'])) {
            die("Gambar tidak terkirim!");
        }

        $nama = $_POST['nama'];
        $harga = $_POST['harga'];

        $fileName = $_FILES['gambar']['name'];
        $tmpName = $_FILES['gambar']['tmp_name'];

        // folder upload
        $folder = __DIR__ . '/../../public/uploads/';

        // pindahkan file
        move_uploaded_file($tmpName, $folder . $fileName);

        // simpan ke database
        $model = new Produk();
        $model->insert($nama, $harga, $fileName);

        header("Location: index.php?page=produk");
    }

    // HAPUS (opsional tapi penting)
    public function hapus() {
        $id = $_GET['id'];
        $model = new Produk();
        $model->delete($id);

        header("Location: index.php?page=produk");
    }
}