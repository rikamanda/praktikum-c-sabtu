<?php

require_once __DIR__ . '/../models/Supplier.php';

class SupplierController {

    public function index() {
        $model = new Supplier();
        $data = $model->all();
        require __DIR__ . '/../views/supplier/index.php';
    }
}