<?php include __DIR__ . '/../layout/header.php'; ?>

<h1>Dashboard Butik</h1>

<div style="display:flex; gap:15px; flex-wrap:wrap;">

    <div class="card">
        <h3>Produk</h3>
        <p>Kelola semua produk butik</p>
    </div>

    <div class="card">
        <h3>Kategori</h3>
        <p>Data kategori fashion</p>
    </div>

    <div class="card">
        <h3>Supplier</h3>
        <p>Data supplier bahan</p>
    </div>

    <div class="card">
        <h3>Transaksi</h3>
        <p>Riwayat penjualan</p>
    </div>

</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>