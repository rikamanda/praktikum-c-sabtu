<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Butik Baju</title>

    <!-- FIX PATH CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar">

    <a href="index.php?page=dashboard">Dashboard</a>
    <a href="index.php?page=produk">Produk</a>
    <a href="index.php?page=kategori">Kategori</a>
    <a href="index.php?page=supplier">Supplier</a>
    <a href="index.php?page=transaksi">Transaksi</a>

</div>

<div class="container">