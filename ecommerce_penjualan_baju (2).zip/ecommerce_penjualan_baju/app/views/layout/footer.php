</div> <!-- penutup container dari header -->

<!-- FOOTER START -->
<footer class="footer">

    <div class="footer-container">

        <!-- Tentang -->
        <div class="footer-box">
            <h3>Butik Baju</h3>
            <p>
                E-commerce fashion modern! 
                Menyediakan produk terbaik dengan harga terjangkau.
            </p>
        </div>

        <!-- Menu -->
        <div class="footer-box">
            <h4>Menu</h4>
            <ul>
                <li><a href="index.php?page=produk">Produk</a></li>
                <li><a href="index.php?page=kategori">Kategori</a></li>
                <li><a href="index.php?page=supplier">Supplier</a></li>
                <li><a href="index.php?page=transaksi">Transaksi</a></li>
            </ul>
        </div>

        <!-- Kontak -->
        <div class="footer-box">
            <h4>Kontak</h4>
            <p>Email: support@butikbaju.com</p>
            <p>WhatsApp: 08xxxxxxxxxx</p>
            <p>Bandung, Indonesia</p>
        </div>

    </div>

    <div class="footer-bottom">
        <small>&copy; <?= date('Y'); ?> Butik Baju. All Rights Reserved.</small>
    </div>

</footer>

</body>
</html>