<?php include __DIR__ . '/../layout/header.php'; ?>

<h2>Tambah Produk Butik Amanda</h2>

<form method="POST" enctype="multipart/form-data"
      action="index.php?page=produk_simpan">

    <label>Nama Produk</label><br>
    <input type="text" name="nama" required><br><br>

    <label>Harga</label><br>
    <input type="number" name="harga" required><br><br>

    <label>Kategori</label><br>
    <select name="kategori">
        <option>Baju</option>
        <option>Sepatu</option>
        <option>Tas</option>
        <option>Jaket</option>
        <option>Celana</option>
    </select><br><br>

    <label>Gambar Produk</label><br>
    <input type="file" name="gambar" required><br><br>

    <button type="submit">Simpan Produk</button>

</form>

<?php include __DIR__ . '/../layout/footer.php'; ?>