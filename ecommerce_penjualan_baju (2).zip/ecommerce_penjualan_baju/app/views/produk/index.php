<?php include __DIR__ . '/../layout/header.php'; ?>

<h2>Produk Butik Amanda</h2>

<a href="index.php?page=produk_tambah">
    <button>+ Tambah Produk</button>
</a>

<div class="product-grid">

<?php foreach($data as $p): ?>

<div class="product-card">

    <img src="uploads/<?= $p['gambar'] ?>" alt="produk">

    <h3><?= $p['nama'] ?></h3>

    <p class="price">
        Rp <?= number_format($p['harga']) ?>
    </p>

    <div class="action">
        <a href="index.php?page=produk_edit&id=<?= $p['id'] ?>">
            <button>Edit</button>
        </a>

        <a href="index.php?page=produk_hapus&id=<?= $p['id'] ?>">
            <button>Hapus</button>
        </a>

        <a href="#">
            <button>+ Keranjang</button>
        </a>
    </div>

</div>

<?php endforeach; ?>

</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>