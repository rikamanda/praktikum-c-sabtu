<?php include __DIR__ . '/../layout/header.php'; ?>

<h2>Supplier</h2>

<table>
<tr><th>ID</th><th>Nama</th></tr>

<?php foreach($data as $s): ?>
<tr>
<td><?= $s['id'] ?></td>
<td><?= $s['nama'] ?></td>
</tr>
<?php endforeach; ?>

</table>

<?php include __DIR__ . '/../layout/footer.php'; ?>