<?php include __DIR__ . '/../layout/header.php'; ?>

<h2>Kategori</h2>

<table>
<tr><th>ID</th><th>Nama</th></tr>

<?php foreach($data as $k): ?>
<tr>
<td><?= $k['id'] ?></td>
<td><?= $k['nama'] ?></td>
</tr>
<?php endforeach; ?>

</table>

<?php include __DIR__ . '/../layout/footer.php'; ?>