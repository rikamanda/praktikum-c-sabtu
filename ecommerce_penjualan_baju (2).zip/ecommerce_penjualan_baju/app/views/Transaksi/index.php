<?php include __DIR__ . '/../layout/header.php'; ?>

<h2>Transaksi</h2>

<table>
<tr><th>ID</th><th>Total</th></tr>

<?php foreach($data as $t): ?>
<tr>
<td><?= $t['id'] ?></td>
<td><?= $t['total'] ?></td>
</tr>
<?php endforeach; ?>

</table>

<?php include __DIR__ . '/../layout/footer.php'; ?>