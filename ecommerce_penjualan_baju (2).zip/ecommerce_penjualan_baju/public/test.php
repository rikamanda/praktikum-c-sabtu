<?php
require_once "../app/config/Database.php";

var_dump(Database::connect());