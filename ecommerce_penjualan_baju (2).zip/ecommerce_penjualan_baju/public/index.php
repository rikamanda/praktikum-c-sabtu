<?php

$page = $_GET['page'] ?? 'dashboard';

/* ================= CONTROLLER ================= */
require_once __DIR__ . "/../app/controllers/DashboardController.php";
require_once __DIR__ . "/../app/controllers/ProdukController.php";
require_once __DIR__ . "/../app/controllers/KategoriController.php";
require_once __DIR__ . "/../app/controllers/SupplierController.php";
require_once __DIR__ . "/../app/controllers/TransaksiController.php";

/* ================= OBJECT ================= */
$dashboard = new DashboardController();
$produk = new ProdukController();
$kategori = new KategoriController();
$supplier = new SupplierController();
$transaksi = new TransaksiController();

/* ================= ROUTING ================= */
switch($page){

    /* ---------- DASHBOARD ---------- */
    case 'dashboard':
        $dashboard->index();
    break;

    /* ---------- PRODUK ---------- */
    case 'produk':
        $produk->index();
    break;

    case 'produk_tambah':
        $produk->tambah();
    break;

    case 'produk_simpan':
        $produk->simpan();
    break;

    case 'produk_edit':
        $produk->edit();
    break;

    case 'produk_update':
        $produk->update();
    break;

    case 'produk_hapus':
        $produk->hapus();
    break;

    /* ---------- KATEGORI ---------- */
    case 'kategori':
        $kategori->index();
    break;

    case 'kategori_tambah':
        $kategori->tambah();
    break;

    case 'kategori_simpan':
        $kategori->simpan();
    break;

    case 'kategori_hapus':
        $kategori->hapus();
    break;

    /* ---------- SUPPLIER ---------- */
    case 'supplier':
        $supplier->index();
    break;

    case 'supplier_tambah':
        $supplier->tambah();
    break;

    case 'supplier_simpan':
        $supplier->simpan();
    break;

    case 'supplier_hapus':
        $supplier->hapus();
    break;

    /* ---------- TRANSAKSI ---------- */
    case 'transaksi':
        $transaksi->index();
    break;

    case 'transaksi_tambah':
        $transaksi->tambah();
    break;

    case 'transaksi_simpan':
        $transaksi->simpan();
    break;

    case 'transaksi_hapus':
        $transaksi->hapus();
    break;

    /* ---------- DEFAULT ---------- */
    default:
        echo "<h2 style='color:red'>Halaman tidak ditemukan</h2>";
    break;
}